const { MongoClient } = require("mongodb");
const uri = "mongodb://127.0.0.1:27017/";
const client = new MongoClient(uri);

async function run() {
  try {

    client.connect().then( ( mongoClient ) => {
        const db = mongoClient.db("classdb");
        const myobj = { name: "Company Inc", address: "Highway 37" };
        db.collection("customer_new").insertOne(myobj, function(err, res) {
            if (err) 
                throw err;
            console.log("1 document inserted");
            mongoClient.close();
        });
    });
  } catch (err) {
    console.log(err);
  }

}

run().catch(console.dir);

console.log('running...');