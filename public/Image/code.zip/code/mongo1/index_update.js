const { MongoClient, ObjectId } = require("mongodb");
const uri = "mongodb://127.0.0.1:27017/";
const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    const database = await client.db("classdb");
    console.log("Connected successfully to server");
    const collection = database.collection('customer').updateOne({
        _id: ObjectId("")
    }, {

    });
    console.log(records);
  } catch (err) {
    console.log(err);
  } finally {
    await client.close();
  }
}


run().catch(console.dir);

console.log('running...');