const { MongoClient } = require('mongodb');
const url = "mongodb://127.0.0.1:27017/"
const client = new MongoClient(url);

async function main() {
    await client.connect();
    const database = client.db("library");
    const collection = database.collection("books");
    
    // Books
	// - title : String
	// - author : String
	// - language : String
	// - edition : String
	// - dateOfPublish : Date
	// - prices : Number
    
    const book = {
        "title" : "harry potter part 2",
        "author" : "JK Rowling",
        "language" : "English",
        "edition" : "first",
        "cost" : "Rs600"
    };
    
    await collection.insertOne(book);

    console.log('done...');
}


main();