const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const uri = "mongodb://127.0.0.1:27017/classdb";

const bookSchema = new Schema({
    title: String,
    author: ObjectId,
    totalPages: Number,
    publishDate: Date
});

const BookModel = mongoose.model('books', bookSchema);

async function run() {
  try {
    console.log('connecting....');
    await mongoose.connect(uri);
    console.log('connected....');
    
    let book = new BookModel({ 
        title: "book2",
        totalPages: 300,
        publishDate: new Date() 
    });

    const books = await BookModel ([book]);
    console.log(books);
    // const response = await book.save();
    // console.log(response);

    console.log('done');
  } catch (err) {
    console.log(err);
  }
}

run().catch(console.dir);

console.log('running...');