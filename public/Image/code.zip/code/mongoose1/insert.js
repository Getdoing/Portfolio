const mongoose = require("mongoose");
const url = "mongodb://127.0.0.1:27017/classdb"
const Schema = mongoose.Schema;
const BookSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    author: {
        type: String,
        required: true,
    },
    language: {
        type: String,
    },
    edition: {
        type: String,
    },
    dateOfPublish: {
        type: Date,
    },
    prices : {
        type : Number,
    }
});

async function main() {
    try {
        console.log('connecting...');
    
        // connect to database
        await mongoose.connect(url);
        const BookModel = mongoose.model('books', BookSchema);

        // insert 3 data
        const data = {
            "title" : "Champak 4",
            "author": "Pooja",
            "language" : "Hindi",
            "edition": "first",
            "dateOfPublish" : new Date(),
            "prices" : 100,
        };
        const data2 = {
            "title" : "Champak 5",
            "author": "Pooja",
            "language" : "Hindi",
            "edition": "first",
            "dateOfPublish" : new Date(),
            "prices" : 100,
        };
        const data3 = {
            "title" : "Champak 6",
            "author": "Pooja",
            "language" : "Hindi",
            "edition": "first",
            "dateOfPublish" : new Date(),
            "prices" : 100,
        }

        const book1 = new BookModel(data);
        const book2 = new BookModel(data2);
        const book3 = new BookModel(data3);


        const response = await BookModel.insertMany([
            book1,
            book2,
            book3
        ]);
        

        console.log('response...', response);


        console.log('connected...');

        
    } catch (error) {
        console.log(error);
    }
    console.log('done....');
}    

main();

