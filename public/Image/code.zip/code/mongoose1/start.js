const mongoose = require("mongoose");
const url = "mongodb://127.0.0.1:27017/library"

const Schema = mongoose.Schema;

// Books
	// - title : String
	// - author : String
	// - language : String
	// - edition : String
	// - dateOfPublish : Date
	// - prices : Number

const BookSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    author: {
        type: String,
    },
    language: {
        type: String,
    },
    edition: {
        type: String,
    },
    dateOfPublish: {
        type: Date,
    },
    prices : {
        type : Number,
    }
});


async function main() {
    console.log('connecting...');
    try {
        await mongoose.connect(url);
        console.log('connected...');
    
        const BookModel = mongoose.model('books', BookSchema);

        const book = {
            "title" : "Champak 4",
            "author": "Pooja",
            "language" : "Hindi",
            "edition": "first",
            "dateOfPublish" : new Date(),
            "prices" : 100,
        };

        const bookInstance = new BookModel(book);

        await bookInstance.save();

        console.log('saved....');
    
    
    } catch (error) {
        console.log(error);
    }

    console.log('done....');
}    

main();

