const { MongoClient } = require("mongodb");
const url = "mongodb://127.0.0.1:27017/";

const client = new MongoClient(url);

console.log('created client');

async function main() {
    await client.connect();
    console.log('client connected...');

    const database = client.db('prepbyte2');
    const collection = database.collection('mongodbclass2');

    const data = {
        first : "kava",
        last: "ajay"
    };

    await collection.insertOne(data);

    console.log('done..');
    
}


main();



