// delete customer whose _id is "57d28452ed5d4d54e86870b5"

const { MongoClient, ObjectId } = require("mongodb");
const URL = "mongodb://127.0.0.1:27017/";
const client = new MongoClient(URL);

async function main() {
    try {
        await client.connect();
        const database = client.db("classdb");
        const customer = database.collection('customer');

        const findData = await customer.find({
            "first":"Antonio"
        }).toArray();

        console.log('findData...', findData);



        // const response2 = await customer.deleteMany({
        //     "_id" : ObjectId("57d28452ed5d4d54e86870b5")
        // });

        // console.log('delete...', response2);
        
        console.log('done...');
    } catch (error) {
        console.log(error);    
    }
}

main();




