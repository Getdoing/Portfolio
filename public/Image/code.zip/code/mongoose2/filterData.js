const { MongoClient } = require('mongodb');
const url = "mongodb://127.0.0.1:27017/"
const client = new MongoClient(url);

async function main() {
    await client.connect();
    const database = client.db("classdb");
    const collection = database.collection("customer");
    
    const query = { "first" : /^L/ };
    
    const data = await collection
        .find(query)
        .project({
            first: 1,
            transactions: 1
        })
        .sort({
            transactions : -1
        })
        .limit(2)
        .toArray();

    console.log(data);

}


main();