const { MongoClient } = require('mongodb');
const url = "mongodb://127.0.0.1:27017/"
const client = new MongoClient(url);

async function main() {
    await client.connect();
    const database = client.db("classdb");
    const collection = database.collection("customer");
    
    const allDataInArray = await collection.find({}).toArray();

    const cursor = await collection.find({});
    while( (await cursor.hasNext()) ) {
        const data = await cursor.next();
        console.log('data.....', data);
        // ++
        // ---
    }

    // let i = 0;
    // while( i < n ) {
    //     const data = cursor[i++];
    //     console.log('data.....', data);
    // }

}


main();