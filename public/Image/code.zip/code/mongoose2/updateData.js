const { MongoClient, ObjectId } = require('mongodb');
const url = "mongodb://127.0.0.1:27017/"
const client = new MongoClient(url);

async function main() {
    await client.connect();
    const database = client.db("classdb");
    const collection = database.collection("customer");
    
    /*
    { 
    "_id" : ObjectId("57d28452ed5d4d54e8687054"), 
    "first" : "Alan", 
    "last" : "Burton", 
    "email" : "aburton77@bizjournals.com", 
    "dob" : ISODate("1951-10-27T00:44:04.000+0000"), 
    "address" : {
        "street" : {
            "name" : "Carey", 
            "suffix" : "Crossing", 
            "number" : "42"
        }, 
        "city" : "Nashville", 
        "state" : "Tennessee", 
        "zip_code" : "37210"
    }, 
    "user_name" : "aburton77", 
    "package" : "XXL", 
    "prio_support" : false, 
    "registered_on" : ISODate("2014-01-08T03:26:13.000+0000"), 
    "transactions" : NumberInt(51), 
    "interests" : [
        "Technology", 
        "Software"
    ], 
    "device" : "Android phone"
},
    update the first name of 
    customer who lives in street name Carey to "CareyCustomer"
    **/
    

    const response = await collection.updateMany(
        {
            "_id" : { 
                $in : [
                    ObjectId("57d28452ed5d4d54e8686fa5"),
                    ObjectId("57d28452ed5d4d54e8687100")
                ]
            }
        }, 
        {
            $inc: {
                "transactions" : 5,
            }
        }
    );

    console.log(response);

}


main();